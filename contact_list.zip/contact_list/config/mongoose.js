//require the library
const mongoose= require('mongoose');

//connecting to the database
mongoose.connect('mongodb://localhost/contacts_list_db');

//acquiring the connection to check if it is successful
const db=mongoose.connection;

//error
db.on('error',console.error.bind('error connecting is on!'));

//up and running then print the message
db.once('open',function(){
    console.log('Successfully connected to the database');
})